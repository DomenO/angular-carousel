/* version 1.0.0 */
export * from './carousel.component';